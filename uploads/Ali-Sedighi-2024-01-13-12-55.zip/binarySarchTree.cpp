#include <iostream>
using namespace std;

class BST {
	public:
		int data;
		BST *left,*right;
		
		BST(int n)
		{
			data = n;
			left = NULL;
			right = NULL;
		}
};

BST* insert(BST* node,int n)
{
	if(node == NULL)
	{
		return new BST(n);
	}
	
	if(node->data == n) 
	{
		cout << "You cant insert a same value that already inserted!"; exit(0);
	}
	if(node->data > n) node->left = insert(node->left,n);
	if(node->data < n) node->right = insert(node->right,n);
			
	return node;
}

BST* deleteNode(BST* node,int n)
{
	if(node == NULL) return node;
	
	if(node->data > n)
	{
		node->left = deleteNode(node->left,n);
		return node;
	}
	if(node->data < n)
	{
		node->right = deleteNode(node->right,n);
		return node;
	}
	
	if(node->left == NULL)
	{
		BST* temp = node->right;
		delete node;
		return temp;
	}
	if(node->right == NULL)
	{
		BST* temp = node->left;
		delete node;
		return temp;
	}
	else
	{
		BST* succParent = node;
		BST* succ = node->right;
		
		while(succ->left != NULL)
		{
			succParent = succ;
			succ = succ->left;
		}
		if(succParent != node)
		 succParent->left = succ->right;
		else
		 succParent->right = succ->right;
		 
		node->data = succ->data;
		
		delete succ;
		return node;
	}
}
		
void print_inOrder(BST* node)
{
	if(node!=NULL)
	{
		print_inOrder(node->left);
		cout << node->data << " ";
		print_inOrder(node->right);
	}
}

void deleteTree(BST* node)
{
	if(node == NULL) return;
	
	deleteTree(node->left);
	deleteTree(node->right);
	
	delete node;
}

int main()
{
	BST* root;
	
	root = insert(root, 50);
    insert(root, 30);
    insert(root, 20);
    insert(root, 40);
    insert(root, 70);
    insert(root, 60);
    insert(root, 80);
    
    print_inOrder(root);
    
    deleteNode(root,50);
    
    cout << endl;
    print_inOrder(root);
    
    return 0;
}