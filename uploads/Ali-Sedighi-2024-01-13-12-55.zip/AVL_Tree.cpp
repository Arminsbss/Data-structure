#include <iostream>
using namespace std;

class AVL{
	public:
		int data;
		AVL* left;
		AVL* right;
		int h;
		
		AVL(int n)
		{
			data = n;
			left = NULL;
			right = NULL;
			h = 1;
		}
};

int height(AVL* node) {  if(node == NULL) return 0;  return node->h;  }

int max(int a,int b) {  return (a>b) ? a : b;  }


AVL* Rrotate(AVL* y)
{
	AVL* x = y->left;
	AVL* T2 = x->right;
	
	x->right = y;
	y->left = T2;
	
	//y->h = max(height(y->left),height(y->right)) + 1;
	x->h = max(height(x->left),height(x->right)) + 1;
	
	return x;
}

AVL* Lrotate(AVL* x)
{
	AVL* y = x->right;
	AVL* T2 = y->left;
	
	y->left = x;
	x->right = T2;
	
	//x->h = max(height(x->left),height(x->right)) + 1;
	y->h = max(height(y->left),height(y->right)) + 1;
	
	return y;
}

int getBalance(AVL* node)
{
	if(node == NULL) return 0;
	return height(node->left) - height(node->right);
}

AVL* insert(AVL* node,int n)
{
	if(node == NULL) return new AVL(n);
	
	if(node->data > n) node->left = insert(node->left,n);
	else if(node->data < n) node->right = insert(node->right,n);
	else return node;
	
	node->h = 1 + max(height(node->left),height(node->right));
	
	int balance = getBalance(node);
	
	if(balance > 1 && n < node->left->data) return Rrotate(node);
	if(balance < -1 && n > node->right->data) return Lrotate(node);
	
	if(balance > 1 && n > node->left->data)
	{
		node->left = Lrotate(node->left);
		return Rrotate(node);
	}
	if(balance < -1 && n < node->right->data)
	{
		node->right = Rrotate(node->right);
		return Lrotate(node);
	}
	
	return node;
}

void print_inOrder(AVL* node)
{
	if(node!=NULL)
	{
		print_inOrder(node->left);
		cout << node->data << "\n";
		cout << node->h << "\n\n";
		print_inOrder(node->right);
	}
}

void deleteTree(AVL* node)
{
	if(node == NULL) return;
	
	deleteTree(node->left);
	deleteTree(node->right);
	
	delete node;
}

int main()
{
	AVL* root = NULL;  

    root = insert(root, 10);  
    root = insert(root, 20);  
    root = insert(root, 30);  
    root = insert(root, 40);  
	root = insert(root, 50);  
    root = insert(root, 25);
    
    print_inOrder(root);
    
    return 0;
}