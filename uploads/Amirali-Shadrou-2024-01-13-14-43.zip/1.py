class Node:
    def __init__(self, key, prio):
        self.key = key
        self.prio = prio
        self.left = None
        self.right = None

def rotate_right(y):
    x = y.left
    y.left = x.right
    x.right = y
    return x

def rotate_left(x):
    y = x.right
    x.right = y.left
    y.left = x
    return y

def insert(root, key, prio):
    if root is None:
        return Node(key, prio)

    if key < root.key:
        root.left = insert(root.left, key, prio)
        if root.left.prio > root.prio:
            root = rotate_right(root)
    else:
        root.right = insert(root.right, key, prio)
        if root.right.prio > root.prio:
            root = rotate_left(root)

    return root

def array_to_treap(arr):
    root = None
    for prio, key in arr:
        root = insert(root, key, prio)
    return root

def inorder_traversal(root):
    if root:
        inorder_traversal(root.left)
        print(f"({root.key},{root.prio})", end=" ")
        inorder_traversal(root.right)

# آرایه n تایی A
A = [(4, 'a'), (7, 'b'), (2, 'c'), (4, 'd'), (1, 'e'), (6, 'f'), (9, 'g'), (3, 'h'), (8, 'i')]

# ساخت Treap از آرایه A
root = array_to_treap(A)

# چاپ نتیجه
inorder_traversal(root)
